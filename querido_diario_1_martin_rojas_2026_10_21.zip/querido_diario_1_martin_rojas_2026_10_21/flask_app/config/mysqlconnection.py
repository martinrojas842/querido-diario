# Conexion a la base de datos MySQL usando las variables del .env
import os
import pymysql.cursors
from dotenv import load_dotenv

load_dotenv()

class MySQLConnection:
    def __init__(self, db):
        # Toma los datos de conexion desde el archivo .env
        connection = pymysql.connect(
            host = os.getenv("DB_HOST", "localhost"),
            user = os.getenv("DB_USER", "root"),
            password = os.getenv("DB_PASSWORD", ""),
            db = db,
            charset = 'utf8mb4',
            cursorclass = pymysql.cursors.DictCursor,
            autocommit = True
        )
        self.connection = connection

    # Executa las consultas SQL (SELECT, INSERT, UPDATE, DELETE)
    def query_db(self, query, data=None):
        with self.connection.cursor() as cursor:
            try:
                query = cursor.mogrify(query, data)
                cursor.execute(query, data)
                if query.lower().find("insert") >= 0:
                    self.connection.commit()
                    return cursor.lastrowid
                elif query.lower().find("select") >= 0:
                    result = cursor.fetchall()
                    return result
                else:
                    self.connection.commit()
            except Exception as e:
                print("Error en la consulta:", e)
                return False
            finally:
                self.connection.close()

def connectToMySQL(db):
    return MySQLConnection(db)